#=============================================================================
#==== Libraries
#=============================================================================

import os
import sys
import time
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xbmcplugin
import xml.etree.ElementTree as ET

from urllib.request import urlopen
from urllib.request import urlretrieve
from urllib.error import HTTPError, URLError

# **** Passed Parameters
params      = {}
PGM_NAME    = sys.argv[0] # sources_array.py
VARS        = sys.argv[1]
url_vars    = VARS
url_vars    = url_vars.replace('%3d', '=')
url_vars    = url_vars.replace('%3D', '=')
url_vars    = url_vars.split('?', 1)[-1]
pairs       = url_vars.split('&')
for pair in pairs:
    split = pair.split('=')
    if len(split) > 1: params[split[0]] = split[1]

try:    passed_addon    = params['addon']
except: passed_addon    = None
try:    passed_station  = params['station']
except: passed_station  = None
try:    passed_id       = params['id']
except: passed_id       = passed_station
if (passed_station == "A"): passed_station = "A&E" 
if (passed_station == "A and E"): passed_station = "A&E" 
if (passed_id == "A"): passed_id = "A&E" 
if (passed_id == "A and E"): passed_id = "A&E" 

# **** Global Variables
ADDON                   = xbmcaddon.Addon(id=passed_addon)
ADDON_NAME              = ADDON.getAddonInfo('name')
LOCAL_HOME_PATH         = xbmcvfs.translatePath('special://home/')
LOCAL_PATH_SEPARATOR    = LOCAL_HOME_PATH[(len(LOCAL_HOME_PATH)-1):len(LOCAL_HOME_PATH)]
ECTV_PATH               = LOCAL_HOME_PATH + "ectv" + LOCAL_PATH_SEPARATOR
ALTERNATIVES_FILE       = "http://1812cottages.com/kodi/php/alt_play_links.xml"
MASTER_FILE             = "http://1812cottages.com/kodi/php/listing_master.xml"


#=============================================================================
#==== Functions
#=============================================================================

def log(addon_name, message, level=xbmc.LOGDEBUG):
    # Here is the reason, in case this helps others. The log levels are as follows:
    #   LOGDEBUG
    #   LOGINFO
    #   LOGNOTICE
    #   LOGWARNING
    #   LOGERROR
    #   LOGSEVERE
    #   LOGFATAL
    #   LOGNONE
    try:
        xbmc.log('%s: %s' % (addon_name, message), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass


def get_user_ID ():

    global  ECTV_PATH

    local_file  = ECTV_PATH + "user.xml"
    user_ID     = ""
    try:
        tree = ET.parse(local_file)
    except ET.ParseError as error_message:
        warning_message = warning_messages + "WARNING: Unable to Parse: " + local_file + " *** Status=" + str(error_message)
        log(ADDON_NAME, warning_message, xbmc.LOGWARNING)
    else:
        #==== Parse XML file for versions
        tree = ET.parse(local_file)
        root = tree.getroot() 
        for branch in root.findall('user'):
            if branch.find('id').text: user_ID = branch.find('id').text
        log(ADDON_NAME, "[B][COLOR green]*** user_ID[/COLOR]: "+user_ID+"[/B]", xbmc.LOGWARNING)
    return user_ID


def safe_encode_url(url):
    url       = url.replace("&amp;", "&")
    url       = url.replace("&", "[and]")
    url       = url.replace('=', '[equals]')
    url       = url.replace('%3d', '[equals]')
    url       = url.replace('%3D', '[equals]')
    url       = url.replace('?', '[question]')
    return url


def decode_url(url):
    url    = url.replace('%22', '"')
    url    = url.replace('%26', '&')
    url    = url.replace('%2c', ',')
    url    = url.replace('%2C', ',')
    url    = url.replace('%2f', '/')
    url    = url.replace('%2F', '/')
    url    = url.replace('%3a', ':')
    url    = url.replace('%3A', ':')
    url    = url.replace('%3d', '=')
    url    = url.replace('%3D', '=')
    url    = url.replace('[and]', '&')
    url    = url.replace('[equals]', '=')
    url    = url.replace('[question]', '?')
    return url
    

#=============================================================================
#==== Run the program
#=============================================================================

# Variables
number_of_alternatives = 0
alt_plugin  = ""
master_link = ""

# Arrays
links_array       = [] # Define list ( array)
sources_array     = [] # Define list ( array)    

# Get the user ID
user_ID = get_user_ID()


# *******************************************
# Master file
# *******************************************

# Transfer master file from web to local
local_file  = ECTV_PATH + "listing_master.xml"   
try: copy_command = urlretrieve(MASTER_FILE, local_file)
except URLError as error:
    error_message = error.reason
    log(PGM_NAME, error_message, xbmc.LOGERROR)

# Parse the File
try:
    tree = ET.parse(local_file)
except ET.ParseError as error_message:
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
except OSError as error:
    error_message = error.strerror
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
else:
    # Get the master link
    root = tree.getroot() 
    for master in root.iter('station'):
        master_name = master.find('station_name').text
        #xbmcgui.Dialog().ok("DEBUG", "master_name="+str(master_name))
        if (master_name == passed_id): 
            master_link = master.find('station_link').text
            kodi_player = master.find('kodi_player').text
            alt_plugin  = kodi_player
            links_array.append(master_link)
            sources_array.append("[COLOR limegreen]Current Link: [/COLOR]" + str(master_name) + " ([B]" + str(kodi_player) + "[/B])")
            number_of_alternatives = number_of_alternatives + 1


# *******************************************
# Alternatives file
# *******************************************

# Transfer alternative file from web to local
local_file  = ECTV_PATH + "alt_play_links.xml"   
try: copy_command = urlretrieve(ALTERNATIVES_FILE, local_file)
except URLError as error:
    error_message = error.reason
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    
# Parse the File
try:
    tree = ET.parse(local_file)
except ET.ParseError as error_message:
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
except OSError as error:
    error_message = error.strerror
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
else:
    # Get the alt link - <alternative name="ABC" id="ABC" thumb="http://1812cottages.com/kodi/media/tvlisting/ABC.jpg" plugin="the-loop">plugin://plugin.video.the-loop/play_video/eyJ0eXBlIjogIml0ZW0iLCAidGl0bGUiOiAiQUJDIiwgImxpbmsiOiBbInBsdWdpbjovL3BsdWdpbi52aWRlby50aGUtbG9vcC9zZWFyY2hfanNvbi9odHRwczovL2xvb3BhZGRvbi51ay9maWxlcy9rMTkveG1scy9DSEFOTkVMX0xJU1QvQUJDLmpzb24_cXVlcnk9ICZkaWFsb2c9dHJ1ZSJdLCAidGh1bWJuYWlsIjogImh0dHBzOi8vd3d3LmZyZWVwbmdsb2dvcy5jb20vdXBsb2Fkcy9hYmMtcG5nLWxvZ28vYWJjLWdvbGQtbWVkaWEta2l0LXBuZy1sb2dvLTE3LnBuZyJ9</alternative>
    root = tree.getroot() 
    for alternative in root.iter('alternative'):
        alt_id      = alternative.get('id')
        if (alt_id == passed_id): 
            alt_link    = alternative.text
            alt_name    = alternative.get('name')
            alt_plugin  = alternative.get('plugin')
            alt_plugin  = alt_plugin.replace('(From ','')
            alt_plugin  = alt_plugin.replace('(','')
            alt_plugin  = alt_plugin.replace(')','')
            if user_ID == "John": alt_plugin = alt_plugin + " [COLOR dimgray] - " + alt_link + "[/COLOR]"
            alt_safe    = safe_encode_url(alt_link);
            master_safe = "" # If not in TVlisting, master_link might not exist
            if master_link: master_safe = safe_encode_url(master_link);
            if (alt_safe == master_safe):
                sources_array[0] = "[COLOR chartreuse]Current Link: " + str(alt_name) + ": " + str(alt_plugin) + "[/COLOR]"
                links_array[0]   = alt_link
            else:
                number_of_alternatives = number_of_alternatives + 1
                sources_array.append("(" + str(number_of_alternatives) + ") [COLOR white][B]" + alt_name + "[/B][/COLOR]: " + alt_plugin)
                links_array.append(alt_link)

if (number_of_alternatives > 1):
    selection_number = xbmcgui.Dialog().select('All Playable Sources for '+passed_station, sources_array)
    if (selection_number > -1):   
        url = decode_url(links_array[selection_number])
        cmd = 'PlayMedia("'+url+'")'
        xbmc.executebuiltin(cmd)
else:
    dialog_message = "No Alternative Links for: [B]"+passed_station+"[/B]"
    if (number_of_alternatives == 1): dialog_message = dialog_message + " \n[I]Currently using: " + alt_plugin + "[/I]"
    xbmcgui.Dialog().ok(ADDON_NAME, dialog_message)
