#=============================================================================
#==== Libraries
#=============================================================================

import os
import sys
import time
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xbmcplugin
import xml.etree.ElementTree as ET
import urllib.parse 

from urllib.request import urlopen
from urllib.request import urlretrieve
from urllib.error import HTTPError, URLError


# **** Passed Parameters
params      = {}
PGM_NAME    = sys.argv[0] # alternative_sources.py
VARS        = sys.argv[1]
url_vars    = VARS
url_vars    = url_vars.replace('%3d', '=')
url_vars    = url_vars.replace('%3D', '=')
url_vars    = url_vars.split('?', 1)[-1]
pairs       = url_vars.split('&')
for pair in pairs:
    split = pair.split('=')
    if len(split) > 1: params[split[0]] = split[1]

try:    passed_addon    = params['addon']
except: passed_addon    = None
try:    passed_station  = params['station']
except: passed_station  = None
try:    passed_id       = params['id']
except: passed_id       = passed_station
try:    passed_value    = params['value']
except: passed_value    = None
try:    passed_field    = params['field']
except: passed_field    = None
if (passed_station == "A"): passed_station = "A&E" 
if (passed_station == "A and E"): passed_station = "A&E" 
if (passed_id == "A"): passed_id = "A&E" 
if (passed_id == "A and E"): passed_id = "A&E" 
passed_value = passed_value.replace("[and]", "&")
passed_value = passed_value.replace("[question]", "?")
passed_value = passed_value.replace("[equals]", "=")

# **** Global Variables
ADDON                   = xbmcaddon.Addon(id=passed_addon)
ADDON_NAME              = ADDON.getAddonInfo('name')
LOCAL_HOME_PATH         = xbmcvfs.translatePath('special://home/')
LOCAL_PATH_SEPARATOR    = LOCAL_HOME_PATH[(len(LOCAL_HOME_PATH)-1):len(LOCAL_HOME_PATH)]
ECTV_PATH               = LOCAL_HOME_PATH + "ectv" + LOCAL_PATH_SEPARATOR
LOCAL_DATA_PATH         = LOCAL_HOME_PATH + "userdata" + LOCAL_PATH_SEPARATOR + "addon_data" + LOCAL_PATH_SEPARATOR + "plugin.video.ectvmenu" + LOCAL_PATH_SEPARATOR
WEB_DATA_PATH           = "http://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/"
PHP_PATH                = "http://1812cottages.com/kodi/php/"


#=============================================================================
#==== Functions
#=============================================================================

def strpos(haystack, needle):
    found_position = haystack.find(needle)
    return found_position


def log(addon_name, message, level=xbmc.LOGDEBUG):
    # Here is the reason, in case this helps others. The log levels are as follows:
    #   LOGDEBUG
    #   LOGINFO
    #   LOGNOTICE
    #   LOGWARNING
    #   LOGERROR
    #   LOGSEVERE
    #   LOGFATAL
    #   LOGNONE
    try:
        xbmc.log('%s: %s' % (addon_name, message), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass


def get_player(link):
	kodi_player	= "player not listed in function get_player in tvlisting/alternative_sources"

	check_player	= "ActivateWindow"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "daddylive"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "dynasty"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "fidoK19"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "ghosttv"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "gratis"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "lntv"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "madtitansports"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "slyguy.samsung"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "super.favourites"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "the-loop"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvlisting"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone11"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone111"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone112"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone1112"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "twistedtv"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	return kodi_player


def change_menu_field (channel_name, channel_id, field, value):
    # Call PHP routine - https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?station_name=CTV+Comedy&station_id=CTV+Comedy&link_name=CTV+Comedy&field=thumb&value=http://img.rapidstreams.io/1/data/images/59440_channels4_profile_2_150x150.jpg&debug=2
    # https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?station_name=MovieTime&station_id=MovieTime&field=media&value=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F145%2F2443%2Fplay.pvr
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "field": field,
        "value": value
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?"+encoded_data
    xbmcgui.Dialog().ok("DEBUG", "process_url="+process_url)
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Change Menu Field: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)


def process_play_link (channel_name, channel_id, link_name, link, player):

    global PGM_NAME

    # Call process_play_link.php routine
    # e.g. https://1812cottages.com/kodi/php/process_play_link.php?station_name=BBC+News&station_id=BBC+News&link_name=BBC+News&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F948%2Fplay.pvr&kodi_player=tv1112&debug=1
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "link_name": link_name,
        "station_link": link,
        "kodi_player": player
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://www.1812cottages.com/kodi/php/process_play_link.php?"+encoded_data
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Update Link: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)


def process_big_list (channel_name, channel_id, link_name, link, player):

    global PGM_NAME

    # Call PHP routine - https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?station_name=BBC+News&station_id=BBC+News&link_name=BBC+News&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F948%2Fplay.pvr&kodi_player=tv1112&debug=
    # e.g. https://1812cottages.com/kodi/php/process_big_list.php?station_name=A%26E&station_id=A%26E&link_name=A%26E+%28Canada%29&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F145%2F2406%2Fplay.pvr&kodi_player=tv112&debug=2
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "link_name": link_name,
        "station_link": link,
        "kodi_player": player
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://www.1812cottages.com/kodi/php/process_big_list.php?"+encoded_data
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Update Link: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)


def transfer_link_files():

    global PGM_NAME

    # Transfer Master File
    web_file    = PHP_PATH + "listing_master.xml"   
    local_file  = ECTV_PATH + "listing_master.xml"   
    try: copy_command = urlretrieve(web_file, local_file)
    except URLError as error:
        log(PGM_NAME, error.reason, xbmc.LOGERROR)

    # Transfer Menu Files that have play links - Not all are displayed on Main Menu
    menus   = ["Apps", "Extras", "Live", "Music", "Other", "Radio", "Sports"]
    for menu in menus:
        # Transfer menu file from web to local
        web_file    = WEB_DATA_PATH + menu + ".xml"   
        local_file  = LOCAL_DATA_PATH + menu + ".xml"   
        try: 
            copy_command = urlretrieve(web_file, local_file)
        except URLError as error:
            log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + web_file + " => [COLOR red]" + str(error) + "[/COLOR]")
            xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to Open: " + web_file + " => [COLOR red]" + str(error) + "[/COLOR]")
        except:
            log(PGM_NAME, "[COLOR red]WARNING: Unable to Transfer: [/COLOR]" + web_file)
            xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to Transfer: "+web_file)
    
    
#=============================================================================
#==== Run the program
#=============================================================================

input_field = ""
if (passed_field == "media"): input_field = "Media"
if (passed_field == "thumb"): input_field = "Thumbnail"
if (passed_field == "fanart"): input_field = "Fanart"
if (passed_field == "desc"): input_field = "Description"
change_field = xbmcgui.Dialog().input("Enter Value for [B]"+input_field+"[/B]", defaultt=passed_value)
if (change_field):
    xbmcgui.Dialog().ok("DEBUG", "passed_station="+passed_station+", passed_id="+passed_id+", passed_field="+passed_field+", change_field="+change_field)
    change_menu_field (passed_station, passed_id, passed_field, change_field)
    if (passed_field == "media"):
        channel_name    = passed_id
        link            = change_field
        player          = get_player(link)
        process_play_link (passed_station, passed_id, channel_name, link, player)
        process_big_list (passed_station, passed_id, channel_name, link, player)
    transfer_link_files()
    xbmc.executebuiltin("Container.Refresh")
