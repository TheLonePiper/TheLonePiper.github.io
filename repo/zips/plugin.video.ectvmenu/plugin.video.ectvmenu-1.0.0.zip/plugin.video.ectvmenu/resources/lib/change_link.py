#=============================================================================
#==== Libraries
#=============================================================================

import os
import sys
import time
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xbmcplugin
import xml.etree.ElementTree as ET
import urllib.parse 

from urllib.request import urlopen
from urllib.request import urlretrieve
from urllib.error import HTTPError, URLError


# **** Passed Parameters
params      = {}
PGM_NAME    = sys.argv[0] # alternative_sources.py
VARS        = sys.argv[1]
url_vars    = VARS
url_vars    = url_vars.replace('%3d', '=')
url_vars    = url_vars.replace('%3D', '=')
url_vars    = url_vars.split('?', 1)[-1]
pairs       = url_vars.split('&')
for pair in pairs:
    split = pair.split('=')
    if len(split) > 1: params[split[0]] = split[1]

try:    passed_addon    = params['addon']
except: passed_addon    = None
try:    passed_station  = params['station']
except: passed_station  = None
try:    passed_id       = params['id']
except: passed_id       = passed_station
try:    passed_hide     = params['hide']
except: passed_hide     = ""
if (passed_station == "A"): passed_station = "A&E" 
if (passed_station == "A and E"): passed_station = "A&E" 
if (passed_id == "A"): passed_id = "A&E" 
if (passed_id == "A and E"): passed_id = "A&E" 

# **** Global Variables
ADDON                   = xbmcaddon.Addon(id=passed_addon)
ADDON_NAME              = ADDON.getAddonInfo('name')
LOCAL_HOME_PATH         = xbmcvfs.translatePath('special://home/')
LOCAL_PATH_SEPARATOR    = LOCAL_HOME_PATH[(len(LOCAL_HOME_PATH)-1):len(LOCAL_HOME_PATH)]
LOCAL_ECTV_PATH         = LOCAL_HOME_PATH + "ectv" + LOCAL_PATH_SEPARATOR
LOCAL_DATA_PATH         = LOCAL_HOME_PATH + "userdata" + LOCAL_PATH_SEPARATOR + "addon_data" + LOCAL_PATH_SEPARATOR + "plugin.video.ectvmenu" + LOCAL_PATH_SEPARATOR
WEB_DATA_PATH           = "http://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/"
WEB_PHP_PATH            = "http://1812cottages.com/kodi/php/"
ALTERNATIVES_FILE       = "http://1812cottages.com/kodi/php/alt_play_links.xml"
MASTER_FILE             = "http://1812cottages.com/kodi/php/listing_master.xml"

# Arrays
alternative_links       = [] # Define list ( array)
alternative_sources     = [] # Define list ( array)    


#=============================================================================
#==== Functions
#=============================================================================

def strpos(haystack, needle):
    found_position = haystack.find(needle)
    return found_position


def log(addon_name, message, level=xbmc.LOGDEBUG):
    # Here is the reason, in case this helps others. The log levels are as follows:
    #   LOGDEBUG
    #   LOGINFO
    #   LOGNOTICE
    #   LOGWARNING
    #   LOGERROR
    #   LOGSEVERE
    #   LOGFATAL
    #   LOGNONE
    try:
        xbmc.log('%s: %s' % (addon_name, message), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass


def get_player(link):
	kodi_player	= "player not listed in function get_player in tvlisting/alternative_sources"

	check_player	= "ActivateWindow"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "daddylive"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "dynasty"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "fidoK19"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "ghosttv"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "gratis"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "lntv"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "madtitansports"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "slyguy.samsung"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "super.favourites"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "the-loop"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvlisting"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone11"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone111"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone112"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "tvone1112"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	check_player	= "twistedtv"
	player_position	= strpos(link, check_player)
	if (player_position > -1): kodi_player = check_player

	return kodi_player


def process_play_link (channel_name, channel_id, link_name, link, player):

    global PGM_NAME

    # Call process_play_link.php routine
    # e.g. https://1812cottages.com/kodi/php/process_play_link.php?station_name=BBC+News&station_id=BBC+News&link_name=BBC+News&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F948%2Fplay.pvr&kodi_player=tv1112&debug=1
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "link_name": link_name,
        "station_link": link,
        "kodi_player": player
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://www.1812cottages.com/kodi/php/process_play_link.php?"+encoded_data
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Update Link: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)


def process_menu_link (channel_name, channel_id, link_name, link, player):

    global PGM_NAME

    # Call PHP routine - https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?station_name=BBC+News&station_id=BBC+News&link_name=BBC+News&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F948%2Fplay.pvr&kodi_player=tv1112&debug=
    # e.g. https://1812cottages.com/kodi/php/process_menu_link.php?station_name=A%26E&station_id=A%26E&link_name=A%26E+%28Canada%29&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F145%2F2406%2Fplay.pvr&kodi_player=tv112&debug=2
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "link_name": link_name,
        "station_link": link,
        "kodi_player": player
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://1812cottages.com/kodi/php/process_menu_link.php?"+encoded_data
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Update Link: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)


def process_big_list (channel_name, channel_id, link_name, link, player):

    global PGM_NAME

    # Call PHP routine - https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?station_name=BBC+News&station_id=BBC+News&link_name=BBC+News&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F948%2Fplay.pvr&kodi_player=tv1112&debug=
    # e.g. https://1812cottages.com/kodi/php/process_big_list.php?station_name=A%26E&station_id=A%26E&link_name=A%26E+%28Canada%29&station_link=plugin%3A%2F%2Fplugin.video.tvone112%2Fplay%2F145%2F2406%2Fplay.pvr&kodi_player=tv112&debug=2
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "link_name": link_name,
        "station_link": link,
        "kodi_player": player
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://www.1812cottages.com/kodi/php/process_big_list.php?"+encoded_data
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Update Link: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)


def transfer_link_files():

    global PGM_NAME

    # Transfer Master File
    web_file    = WEB_PHP_PATH + "listing_master.xml"   
    local_file  = LOCAL_ECTV_PATH + "listing_master.xml"   
    try: copy_command = urlretrieve(web_file, local_file)
    except URLError as error:
        log(PGM_NAME, error.reason, xbmc.LOGERROR)

    # Transfer Menu Files that have play links - Not all are displayed on Main Menu
    menus   = ["TV", "Sports", "Extras", "Single_Show_Channels", "Secret"]
    for menu in menus:
        # Transfer menu file from web to local
        web_file    = WEB_DATA_PATH + menu + ".xml"   
        local_file  = LOCAL_DATA_PATH + menu + ".xml"   
        try: 
            copy_command = urlretrieve(web_file, local_file)
        except URLError as error:
            log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + web_file + " => [COLOR red]" + str(error) + "[/COLOR]")
            xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to Open: " + web_file + " => [COLOR red]" + str(error) + "[/COLOR]")
        except:
            log(PGM_NAME, "[COLOR red]WARNING: Unable to Transfer: [/COLOR]" + web_file)
            xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to Transfer: "+web_file)
    
    
def safe_encode_url(url):
    url       = url.replace("&amp;", "&")
    url       = url.replace("&", "[and]")
    url       = url.replace('=', '[equals]')
    url       = url.replace('%3d', '[equals]')
    url       = url.replace('%3D', '[equals]')
    url       = url.replace('?', '[question]')
    return url


#=============================================================================
#==== Run the program
#=============================================================================

# Variables
number_of_alternatives = 0
master_link = ""


# *******************************************
# Master file
# *******************************************

# Transfer master file from web to local
local_file  = LOCAL_ECTV_PATH + "listing_master.xml"   
try: copy_command = urlretrieve(MASTER_FILE, local_file)
except URLError as error:
    error_message = error.reason
    log(PGM_NAME, error_message, xbmc.LOGERROR)

# Parse the File
try:
    tree = ET.parse(local_file)
except ET.ParseError as error_message:
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
except OSError as error:
    error_message = error.strerror
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
else:
    # Get the master link
    root = tree.getroot() 
    for master in root.iter('station'):
        master_name = master.find('station_name').text
        #xbmcgui.Dialog().ok("DEBUG", "master_name="+str(master_name))
        if (master_name == passed_id): 
            master_link = master.find('station_link').text
            kodi_player = master.find('kodi_player').text
            alt_plugin  = kodi_player
            alternative_links.append(master_link)
            alternative_sources.append("[COLOR limegreen]Current Link: [/COLOR]" + str(master_name) + " ([B]" + str(kodi_player) + "[/B])")
            number_of_alternatives = number_of_alternatives + 1


# *******************************************
# Alternatives file
# *******************************************

# Transfer alternative file from web to local
local_file  = LOCAL_ECTV_PATH + "alt_play_links.xml"   
try: copy_command = urlretrieve(ALTERNATIVES_FILE, local_file)
except URLError as error:
    log(PGM_NAME, error.reason, xbmc.LOGERROR)
    
# Parse the File
try:
    tree = ET.parse(local_file)
except ET.ParseError as error_message:
    log(PGM_NAME, error_message, xbmc.LOGERROR)
    pass
except OSError as error:
    log(PGM_NAME, error.strerror, xbmc.LOGERROR)
    pass
else:
    # Get the alt link - <alternative name="ABC" id="ABC" thumb="http://1812cottages.com/kodi/media/tvlisting/ABC.jpg" plugin="the-loop">plugin://plugin.video.the-loop/play_video/eyJ0eXBlIjogIml0ZW0iLCAidGl0bGUiOiAiQUJDIiwgImxpbmsiOiBbInBsdWdpbjovL3BsdWdpbi52aWRlby50aGUtbG9vcC9zZWFyY2hfanNvbi9odHRwczovL2xvb3BhZGRvbi51ay9maWxlcy9rMTkveG1scy9DSEFOTkVMX0xJU1QvQUJDLmpzb24_cXVlcnk9ICZkaWFsb2c9dHJ1ZSJdLCAidGh1bWJuYWlsIjogImh0dHBzOi8vd3d3LmZyZWVwbmdsb2dvcy5jb20vdXBsb2Fkcy9hYmMtcG5nLWxvZ28vYWJjLWdvbGQtbWVkaWEta2l0LXBuZy1sb2dvLTE3LnBuZyJ9</alternative>
    root = tree.getroot() 
    for alternative in root.iter('alternative'):
        alt_id      = alternative.get('id')
        if (alt_id == passed_id): 
            alt_link    = alternative.text
            alt_name    = alternative.get('name')
            alt_plugin  = alternative.get('plugin')
            alt_plugin  = alt_plugin.replace('(From ','')
            alt_plugin  = alt_plugin.replace('(','')
            alt_plugin  = alt_plugin.replace(')','')
            alt_plugin = alt_plugin + " [COLOR dimgray] - " + alt_link + "[/COLOR]"
            alt_safe    = safe_encode_url(alt_link);
            master_safe = "" # If not in TVlisting, master_link might not exist
            if master_link: master_safe = safe_encode_url(master_link);
            if (alt_safe == master_safe):
                alternative_sources[0] = "[COLOR chartreuse]Current Link: " + str(alt_name) + ": " + str(alt_plugin) + "[/COLOR]"
                alternative_links[0]   = alt_link
            else:
                number_of_alternatives = number_of_alternatives + 1
                alternative_sources.append("(" + str(number_of_alternatives) + ") [COLOR white][B]" + alt_name + "[/B][/COLOR]: " + alt_plugin)
                alternative_links.append(alt_link)

if (number_of_alternatives > 1):
    # List all links
    selection_number = xbmcgui.Dialog().select('Change Media Link for: [B]'+passed_station+'[/B]', alternative_sources)

    # If selection, play link
    if (selection_number > -1):   
        color           = "green"
        process_action  = "Update"
        process_type    = "TVListings"
        set_to          = " to "+alternative_sources[selection_number]
        link            = alternative_links[selection_number]
        proceed = xbmcgui.Dialog().yesno(process_action+" "+process_type+" Link", process_action+" "+process_type+" link for [B][COLOR "+color+"]"+passed_station+"[/COLOR][/B]"+set_to+" ?")
        if (proceed):
            player  = get_player(link)
            process_play_link (passed_station, passed_id, passed_station, link, player)
            process_menu_link (passed_station, passed_id, passed_station, link, player)
            process_big_list (passed_station, passed_id, passed_station, link, player)
            transfer_link_files()
            xbmc.executebuiltin("Container.Refresh")
else:
    xbmcgui.Dialog().ok(ADDON_NAME, "No Alternative Links for: [B]"+passed_station+"[/B]")
