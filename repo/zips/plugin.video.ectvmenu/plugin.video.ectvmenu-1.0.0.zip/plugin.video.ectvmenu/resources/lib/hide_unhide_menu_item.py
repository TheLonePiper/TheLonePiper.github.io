#=============================================================================
#==== Libraries
#=============================================================================

import os
import sys
import time
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xbmcplugin
import xml.etree.ElementTree as ET
import urllib.parse 

from urllib.request import urlopen
from urllib.request import urlretrieve
from urllib.error import HTTPError, URLError


# **** Passed Parameters
params      = {}
PGM_NAME    = sys.argv[0] # alternative_sources.py
VARS        = sys.argv[1]
url_vars    = VARS
url_vars    = url_vars.replace('%3d', '=')
url_vars    = url_vars.replace('%3D', '=')
url_vars    = url_vars.split('?', 1)[-1]
pairs       = url_vars.split('&')
for pair in pairs:
    split = pair.split('=')
    if len(split) > 1: params[split[0]] = split[1]

try:    passed_addon    = params['addon']
except: passed_addon    = None
try:    passed_station  = params['station']
except: passed_station  = None
try:    passed_id       = params['id']
except: passed_id       = passed_station
try:    passed_hide     = params['hide']
except: passed_hide     = ""
if (passed_id == "A and E"): passed_id = "A&E" 

# **** Global Variables
ADDON                   = xbmcaddon.Addon(id=passed_addon)
ADDON_NAME              = ADDON.getAddonInfo('name')
LOCAL_HOME_PATH         = xbmcvfs.translatePath('special://home/')
LOCAL_PATH_SEPARATOR    = LOCAL_HOME_PATH[(len(LOCAL_HOME_PATH)-1):len(LOCAL_HOME_PATH)]
LOCAL_ECTV_PATH         = LOCAL_HOME_PATH + "ectv" + LOCAL_PATH_SEPARATOR
LOCAL_DATA_PATH         = LOCAL_HOME_PATH + "userdata" + LOCAL_PATH_SEPARATOR + "addon_data" + LOCAL_PATH_SEPARATOR + "plugin.video.ectvmenu" + LOCAL_PATH_SEPARATOR
WEB_DATA_PATH           = "http://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/"
WEB_PHP_PATH            = "http://1812cottages.com/kodi/php/"
ALTERNATIVES_FILE       = "http://1812cottages.com/kodi/php/alt_play_links.xml"

# Arrays
alternative_links       = [] # Define list ( array)
alternative_names       = [] # Define list ( array)
alternative_sources     = [] # Define list ( array)    


#=============================================================================
#==== Functions
#=============================================================================

def log(addon_name, message, level=xbmc.LOGDEBUG):
    # Here is the reason, in case this helps others. The log levels are as follows:
    #   LOGDEBUG
    #   LOGINFO
    #   LOGNOTICE
    #   LOGWARNING
    #   LOGERROR
    #   LOGSEVERE
    #   LOGFATAL
    #   LOGNONE
    try:
        xbmc.log('%s: %s' % (addon_name, message), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass


def hide_unhide_menu_item (channel_name, channel_id, hide_item):
    # Call PHP routine - https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?station_name=BBC+News&station_id=CTV+Comedy&link_name=CTV+Comedy&hide=true&debug=1
    data = {
        "station_name": channel_name,
        "station_id": channel_id,
        "hide_item": hide_item
    }
    encoded_data  = urllib.parse.urlencode(data)
    process_url   = "https://1812cottages.com/kodi/userdata/addon_data/plugin.video.ectvmenu/process_menu_link.php?"+encoded_data
    try:
        urlopen(process_url)
        log(PGM_NAME, "[COLOR green]Update Menu Hide/Unhide: [/COLOR]" + process_url)
    except urllib.error.URLError as e:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except Exception as e:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: " + process_url + " => [COLOR red]" + str(e) + "[/COLOR]")
    except:
        log(PGM_NAME, "[COLOR red]WARNING: Unable to Open: [/COLOR]" + process_url)
        xbmcgui.Dialog().ok(channel_name, "[COLOR red]WARNING:[/COLOR] Failed to change TV Listing link: "+process_url)


def transfer_link_files():
    # Transfer Menu Files
    menus   = ["Live", "Sports", "Apps", "Music", "Radio", "Extras", "Favs"]
    for menu in menus:
        # Transfer menu file from web to local
        web_file    = WEB_DATA_PATH + menu + ".xml"   
        local_file  = LOCAL_DATA_PATH + menu + ".xml"   
        try: copy_command = urlretrieve(web_file, local_file)
        except URLError as error:
            log(PGM_NAME, error.reason, xbmc.LOGERROR)
    
    
#=============================================================================
#==== Run the program
#=============================================================================

hide_unhide_menu_item (passed_station, passed_id, passed_hide)
transfer_link_files()
xbmc.executebuiltin("Container.Refresh")
