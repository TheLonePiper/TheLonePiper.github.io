
import sys
import xbmc


if __name__ == '__main__':
    cmd = sys.argv[1]

    if cmd.lower().startswith('executebuiltin'): cmd = cmd[15:-1]
    
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.executebuiltin(cmd)
   