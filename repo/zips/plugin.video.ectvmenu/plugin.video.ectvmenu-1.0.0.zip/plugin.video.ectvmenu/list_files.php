<?php
// open this directory
$myDirectory = opendir(".");

// get each entry
while($entryName = readdir($myDirectory)) {
$dirArray[] = $entryName;
}

// close directory
closedir($myDirectory);

// sort 'em
sort($dirArray);

// count elements in array
$indexCount = count($dirArray);

// loop through the array of files and print them all
for($index=0; $index < $indexCount; $index++) {
	if (substr("$dirArray[$index]", 0, 1) != "."){ // don't list hidden files
		$file_type = (filetype($dirArray[$index]));
		if ($file_type == "file") { // don't include dir
			$file_name 	= $dirArray[$index];
			$php_file	= strpos($file_name,".php");	
			if ($php_file != true and $file_name <> "error_log") { // don't include known system files
				print("<p>".$file_name."</p>");
			}
		}
	}

}


?>