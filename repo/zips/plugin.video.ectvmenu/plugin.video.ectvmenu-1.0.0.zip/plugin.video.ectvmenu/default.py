# Widget => plugin://plugin.video.extvmenu/?menu=TV
# Movies => plugin://plugin.video.extvmenu/?name=Trending+Recent^mode=build_movie_list&action=trakt_movies_trending_recent&random_support=true

#=============================================================================
#==== Libraries
#=============================================================================

import os
import sys
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
import xbmcplugin
import xml.etree.ElementTree as ET
import itertools 
import urllib.parse 
import time

from urllib.error import HTTPError, URLError
from urllib.request import urlretrieve
from urllib.request import urlopen
from datetime import date, datetime, timedelta


# **** Global Variables
ADDON                   = xbmcaddon.Addon()
ADDON_NAME              = ADDON.getAddonInfo('name')
ADDON_ID                = ADDON.getAddonInfo('id')
ADDON_FANART            = ADDON.getAddonInfo('fanart')
ADDON_PATH              = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ICONS_DIR               = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
HANDLE                  = int(sys.argv[1])
HOME                    = ADDON.getAddonInfo('path')
HOME_PATH               = xbmcvfs.translatePath('special://home/')
PATH_SEPARATOR          = HOME_PATH[(len(HOME_PATH)-1):len(HOME_PATH)]
ECTV_PATH               = HOME_PATH + "ectv" + PATH_SEPARATOR
DATA_PATH               = HOME_PATH + "userdata" + PATH_SEPARATOR + "addon_data" + PATH_SEPARATOR + "plugin.video.ectvmenu" + PATH_SEPARATOR
SYSADDON                = sys.argv[0]
VARS                    = sys.argv[2]
LOCAL_HOME_PATH         = xbmcvfs.translatePath('special://home/')
LOCAL_PATH_SEPARATOR    = LOCAL_HOME_PATH[(len(LOCAL_HOME_PATH)-1):len(LOCAL_HOME_PATH)]
LOCAL_ECTV_PATH         = LOCAL_HOME_PATH + "ectv" + LOCAL_PATH_SEPARATOR
WEB_HOME_PATH           = "https://1812cottages.com/kodi/"
WEB_MEDIA_PATH          = WEB_HOME_PATH + "media/menus/"
WEB_PHP_PATH            = WEB_HOME_PATH + "php/"
USER_LOG_ROUTINE        = "ectv_user_log.php"


#=============================================================================
#==== Functions
#=============================================================================

def log(addon_name, message, level=xbmc.LOGDEBUG):
    # Here is the reason, in case this helps others. The log levels are as follows:
    #   LOGDEBUG
    #   LOGINFO
    #   LOGNOTICE
    #   LOGWARNING
    #   LOGERROR
    #   LOGSEVERE
    #   LOGFATAL
    #   LOGNONE
    try:
        xbmc.log('%s: %s' % (addon_name, message), level)
    except Exception as e:
        try: xbmc.log('Logging Failure: %s' % (e), level)
        except: pass


def get_params(url_vars):
    params      = {}
    url_vars    = url_vars.replace('%5b', '[')
    url_vars    = url_vars.replace('%5B', '[')
    url_vars    = url_vars.replace('%5d', ']')
    url_vars    = url_vars.replace('%5D', ']')
    url_vars    = url_vars.split('?', 1)[-1]
    pairs       = url_vars.split('&')

    for pair in pairs:
        split = pair.split('=')
        if len(split) > 1: 
            params[split[0]] = decode_url(split[1])
            #xbmcgui.Dialog().ok("DEBUG", "[COLOR green]"+split[0]+"[/COLOR]: "+str(split[1]))

    return params


def get_user_ID ():

    global  ECTV_PATH

    local_file  = ECTV_PATH + "user.xml"
    user_ID     = ""
    try:
        tree = ET.parse(local_file)
    except ET.ParseError as error_message:
        warning_message = warning_messages + "WARNING: Unable to Parse: " + local_file + " *** Status=" + str(error_message)
        log(ADDON_NAME, warning_message, xbmc.LOGWARNING)
    else:
        #==== Parse XML file for versions
        tree = ET.parse(local_file)
        root = tree.getroot() 
        for branch in root.findall('user'):
            if branch.find('id').text: user_ID = branch.find('id').text
        log(ADDON_NAME, "[B][COLOR green]*** user_ID[/COLOR]: "+user_ID+"[/B]", xbmc.LOGWARNING)
    return user_ID


def create_item_list(menu_name):

    # Build Super Favourite array
    display_count   = 0

    # Parse Local File
    menu_file       = DATA_PATH + menu_name + ".xml"
#    xbmcgui.Dialog().ok("DEBUG", "menu_file = "+str(menu_file))
    try:
        tree = ET.parse(menu_file)
    except IOError as e:
#        xbmcgui.Dialog().ok(ADDON_NAME, "IOError: "+str(e.strerror)+": "+menu_file)
        log(ADDON_NAME, menu_file+": [COLOR red]"+str(e.strerror)+"[/COLOR]", xbmc.LOGERROR)
        pass
    except ET.ParseError as error_message:
#        xbmcgui.Dialog().ok(ADDON_NAME, "ParseError: "+str(error_message)+": "+menu_file)
        log(ADDON_NAME, menu_file+": [COLOR red]"+str(error_message)+"[/COLOR]", xbmc.LOGERROR)
        pass
    else:
        # Get the playable entries
        root = tree.getroot() 
        for item in root.iter('menu_item'):
            # Ex. <menu_item name="ECTV TV Guide" id="ECTV TV Guide" thumb="special://home/addons\plugin.video.tvlisting\icon.png" fanart="https://1812cottages.com/kodi/media/wallpapers/TVListing-fanart.jpg" desc="View a clickable list of Channels displaying what Shows are on right now. You can customize what Channels are display by holding the SELECT button for two-seconds, or viewing the Settings at the bottom of the list. Long press the SELECT button at anytime to view additional viewing options, categories and search features." execute="addon">RunAddon(&quot;plugin.video.tvlisting&quot;)</menu_item>
            # Ex. <menu_item name="BBC One" id="BBC-1" thumb="https://1812cottages.com/kodi/media/logos/logo_BBC_1.png" fanart="https://1812cottages.com/kodi/media/apps/BBC_Background.jpg" desc="BBC One is a British free-to-air public broadcast television channel owned and operated by the BBC. It is the corporation's oldest and flagship channel, and is known for broadcasting mainstream programming, which includes BBC News television bulletins, primetime drama and entertainment, and live BBC Sport events." execute="">plugin://plugin.video.daddylive/?mode%3Dplay&amp;url%3Dhttps%3A%2F%2Fthedaddy.to%2F%2Fstream%2Fstream-356.php&amp;</menu_item>
            try: name           = item.get('name')
            except: name        = ""   
            try: id             = item.get('id')
            except: id          = ""   
            try: thumb          = item.get('thumb')
            except: thumb       = ""   
            try: fanart         = item.get('fanart')
            except: thumb       = ""   
            try: desc           = item.get('desc')
            except: desc        = ""   
            try: execute        = item.get('execute')
            except: execute     = ""   
            try: hide           = item.get('hide')
            except: hide        = ""   
            try: link_date      = item.get('link_date')
            except: link_date   = ""   
            try: link           = item.text            
            except: link        = ""  
            name = name.replace("%26apos;","'")
            id   = id.replace("%26apos;","'")
            desc = desc.replace("%26apos;","'")
            link = str(link)
            if (link == "None"): link = ""
            url_test = link.split('url=') # Check for url within url
            if len(url_test) == 1: url_test = link.split('url[equals]') # Check for url within url
            if len(url_test) == 1:
                # Not a url, so replace = sign
                # 	    <menu_item name="Christmas Holiday Hits" id="Christmas Holiday Hits" thumb="https://1812cottages.com/kodi/media/extras/Holiday_Hits.jpg" fanart="https://1812cottages.com/kodi/media/wallpapers/Pictures-christmas-wallpapers-hd.jpg" desc="From Bing to Buble, from Mariah to Sinatra, Stingray presents all of the best Christmas Music" execute="" hide="" link_date="2025-11-23 12:37:46">plugin://plugin.video.ghosttv/?url=https%3A%2F%2Fdbrb49pjoymg4.cloudfront.net%2Fv1%2Fmaster%2F3fec3e5cac39a52b2132f9c66c83dae043dc17d4%2Fprod_default_xumo-ams-aws%2Fmaster.m3u8%3Fads.xumo_channelId%3D99991120[and]mode[equals]12</menu_item>
                # vs.   <menu_item name="Tinsel Town" id="Tinsel Town" thumb="https://image.tmdb.org/t/p/w780/tGidrBsBBxUkmdQpIeFI09oLL8F.jpg" fanart="https://image.tmdb.org/t/p/w1280/psAGX272PFGdpKmSJI4x8sGPciZ.jpg" desc="A washed-up Hollywood action hero is tricked into starring in a small English town,s chaotic Christmas pantomime, where a straight-talking dance instructor and his estranged daughter just might help him rediscover the magic of the season." execute="" hide="" link_date="2025-11-28 18:53:05">plugin://plugin.video.fenlight/?mode%3Dplayback.media&amp;media_type%3Dmovie&amp;tmdb_id%3D1430593&amp;playback_integer%3D939145</menu_item>
                link = link.replace("%3D","=")
            if (id == "A&E"): id = "A and E" # Ampersand parses out when sent as URL
            if (id == "A&amp;E"): id = "A and E" # Ampersand parses out when sent as URL
            name_list.append(name)
            id_list.append(id)
            thumb_list.append(thumb)
            fanart_list.append(fanart)
            desc_list.append(desc)
            execute_list.append(execute)
            hide_list.append(hide)
            link_date_list.append(link_date)
            link_list.append(link)


def send_files_to_xbmc(name_list, id_list, thumb_list, fanart_list, desc_list, execute_list, hide_list, link_date_list, link_list): # ** Send to XBMC

    global HANDLE
    global SYSADDON
    
    # Loop through items
    item_count  = 0
    for (name, id, thumb, fanart, desc, execute, hide, link_date, link) in zip(name_list, id_list, thumb_list, fanart_list, desc_list, execute_list, hide_list, link_date_list, link_list): # ** Send to XBMC

        # Display the item
        if (link is None): link = ""
        item_count      = item_count + 1
        original_name   = name
        original_link   = link
        original_thumb  = thumb
        if (hide == "true"):
            name  = original_name+"[COLOR red][I] - Hidden[/I][/COLOR]"
            thumb = WEB_MEDIA_PATH+"hidden.jpg"
        if (user_ID == "John"): 
            if (execute == ""): 
                name = name + "[COLOR cyan] - (Last Updated: [B]" + link_date[:10] + ")[/B] [/COLOR]"
            if (link[:31] == "plugin://plugin.video.daddylive"): 
                name = name + "[COLOR purple] - [B]Daddylive[/B] [/COLOR]"
            if (link[:29] == "plugin://plugin.video.dynasty"): 
                name = name + "[COLOR red] - [B]Dynasty[/B] [/COLOR]"
            if (link[:29] == "plugin://plugin.video.fidoK19"): 
                name = name + "[COLOR orange] - [B]Fido K19[/B] [/COLOR]"
            if (link[:4] == "http"): 
                url_name = name
                name = name + "[COLOR lightsteelblue] - [B]URL[/B] [/COLOR]"
                if (link[:20] == "http://fl1.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl2.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl3.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl4.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl5.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl6.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl7.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
                if (link[:20] == "http://fl8.moveonjoy"): name = url_name + "[COLOR lightsteelblue] - [B]Move on Joy[/B] (URL) [/COLOR]"
            if (link[:29] == "plugin://plugin.video.ghosttv"): 
                name = name + "[COLOR lime] - [B]LNTV[/B] [/COLOR]"
            if (link[:26] == "plugin://plugin.video.lntv"): 
                name = name + "[COLOR white] - [B]LNTV[/B] [/COLOR]"
            if (link[:36] == "plugin://plugin.video.madtitansports"): 
                name = name + "[COLOR yellow] - [B]Mad Titan Sports[/B] [/COLOR]"
            if (link[:15] == "plugin://slyguy"): 
                name = name + "[COLOR deeppink] - [B]Sly Guy[/B] [/COLOR]"
            if (link[:30] == "plugin://plugin.video.the-loop"): 
                name = name + "[COLOR green] - [B]The Loop[/B] [/COLOR]"
            if (link[:31] == "plugin://plugin.video.twistedtv"): 
                name = name + "[COLOR green] - [B]Twisted TV[/B] [/COLOR]"
            if (link[:27] == "plugin://plugin.video.tvone"): 
                name = name + "[COLOR goldenrod] - [B]TVOne[/B] [/COLOR]"
            name = name + "[COLOR grey] - [I]" + link + "[/I] [/COLOR]"
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({'poster' : thumb})
        list_item.setArt({'fanart' : fanart})
        list_item.setLabel(name)
        list_item.setProperty('IsPlayable', 'true')
        is_folder       = False
        menu_item_name  = encode_menu_item_name(original_name)
        context_link    = safe_encode_url(link)
        current_window  = xbmcgui.getCurrentWindowId()
        context_menu    = []
        context_menu.append( ('[COLOR limegreen][B]Refresh[/B] Menu[/COLOR]', 'Container.Refresh') )
        context_menu.append( ('[COLOR limegreen][B]Recent[/B] Channels[/COLOR]', 'RunScript(special://home/addons/plugin.video.tvlisting/resources/lib/recent_channels.py,"")') )
        if (execute != ""): 
            list_item.setProperty('IsPlayable', 'false')
            is_folder = True
            if (user_ID == "John"): context_menu.append( ('[COLOR cyan]Edit [B]Media Link[/B] for '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/change_field.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&value='+context_link+'&field=media")') )
        if (execute == "addon" or execute == "script" or execute == "tvlisting" or execute == "window"): 
            cmd_prefix = ""
            if (current_window == 10000): cmd_prefix = "HOME:"
            if (execute == "script" or execute == "window"): link = safe_encode_url(link)
            link = "plugin://"+ADDON_ID+"/?execute="+str(execute)+"&cmd="+cmd_prefix+link+"&menu_item_name="+menu_item_name
        elif (execute == "folder"): 
            if (link == ""): link = name
            link = "plugin://"+ADDON_ID+"/?reload="+link
        else:
            fenlight = link.find("fenlight")
#            if (current_window == 10000): # Play directly if HOME - plugin?url= form uses [and] [equals]
            if (current_window == 10000 and fenlight > 0): # Direct play Movies or Series
                list_item.setProperty('IsPlayable', 'true')
                link = link.replace("[and]", "&")
                link = link.replace("[equals]", "=")
            else:    
                #Otherwise ExecuteBuiltin to use PlayMedia
                cmd_prefix = ""
                if (current_window == 10000): cmd_prefix = "HOME:"
                list_item.setProperty('IsPlayable', 'false')
                link = link.replace("&", "[and]")
                link = link.replace("=", "[equals]")
                menu_item_url = "&menu_item_name="+menu_item_name
                if (fenlight > 0): menu_item_url = ""
                link = "plugin://"+ADDON_ID+"/?execute=playmedia&cmd="+cmd_prefix+link+menu_item_url
            # *** Build the context menu
            context_menu.append( ('[COLOR cyan][B]More Options[/B] to play '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/alternative_sources.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&hide='+str(hide)+'")') ) # Alternative Links
            if (user_ID == "John" or user_ID == "Lorraine"): context_menu.append( ('[COLOR cyan]Change [B]Media Link[/B] for '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/change_link.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'")') ) # Change Links
        if (user_ID == "John"): 
            name = name + " [COLOR dimgray] - " + link + "[/COLOR]"
            desc = desc + " [COLOR dimgray] - " + link + "[/COLOR]"
            context_menu.append( ('[COLOR cyan]Edit [B]Thumbnail[/B] for '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/change_field.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&value='+thumb+'&field=thumb")') )
            context_menu.append( ('[COLOR cyan]Edit [B]Fanart[/B] for '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/change_field.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&value='+fanart+'&field=fanart")') )
            context_menu.append( ('[COLOR cyan]Edit [B]Description[/B] for '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/change_field.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&value='+desc+'&field=desc")') )
            if (hide == "true"):
                context_menu.append( ('[COLOR green][B]Unhide[/B] '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/hide_unhide_menu_item.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&hide=false")') ) 
            else:
                context_menu.append( ('[COLOR red][B]Hide[/B] '+original_name+'[/COLOR]', 'RunScript(special://home/addons/plugin.video.ectvmenu/resources/lib/hide_unhide_menu_item.py,"?addon='+str(ADDON_ID)+'&station='+original_name+'&id='+str(id)+'&hide=true")') ) 
        list_item.addContextMenuItems(context_menu)

        # Get info tag
        info_tag = list_item.getVideoInfoTag()
        #info_tag.setMediaType('movie')
        info_tag.setMediaType('video')
        info_tag.setTitle(original_name)
        info_tag.setPlot(desc)
        #info_tag.setDuration() # Display beside year
        if (hide == "true"):
            if (current_window == 10000): pass
            elif (user_ID == "John"): xbmcplugin.addDirectoryItem(HANDLE, link, list_item, is_folder)
        else: xbmcplugin.addDirectoryItem(HANDLE, link, list_item, is_folder)

    # Tell xbmc we have finished creating the directory list
    xbmcplugin.endOfDirectory(HANDLE)


def decode_url(url):
    split = url.split('url=') # Check for url within url
    if len(split) == 1: split = url.split('url[equals]') # Check for url within url
    if len(split) > 1: url = split[0]
    url    = url.replace('%22', '"')
    url    = url.replace('%26', '&')
    url    = url.replace('%2c', ',')
    url    = url.replace('%2C', ',')
    url    = url.replace('%2f', '/')
    url    = url.replace('%2F', '/')
    url    = url.replace('%3a', ':')
    url    = url.replace('%3A', ':')
    url    = url.replace('%3d', '=')
    url    = url.replace('%3D', '=')
    url    = url.replace('%3f', '?')
    url    = url.replace('%3F', '?')
    url    = url.replace('[and]', '&')
    url    = url.replace('[equals]', '=')
    url    = url.replace('[question]', '?')
    if len(split) > 1: url = url + "url=" + encode_address(split[1])
    return url
    

def encode_address(address):
    address = address.replace('[and]', '&')
    address = address.replace('[equals]', '=')
    address = address.replace('[question]', '?')
    address = address.replace('/','%2F')
    address = address.replace(':','%3A')
    return address

def encde_url(url):
    url = url.replace('&amp;','&')
    url = url.replace('&','%26')
    url = url.replace('/','%2F')
    url = url.replace(':','%3A')
    url = url.replace('=','%3D')
    url = url.replace('?','%3F')
    return url
    
    
def safe_encode_url(url):
    url       = url.replace("&amp;", "&")
    url       = url.replace("&", "[and]")
    url       = url.replace('=', '[equals]')
    url       = url.replace('%3d', '[equals]')
    url       = url.replace('%3D', '[equals]')
    url       = url.replace('?', '[question]')
    return url
    

def encode_menu_item_name(menu_item_name):
    menu_item_name  = menu_item_name.replace(' ', '%20')
    menu_item_name  = menu_item_name.replace("&amp;", "&")
    menu_item_name  = menu_item_name.replace("&", "[and]")
    menu_item_name  = menu_item_name.replace('=', '[equals]')
    menu_item_name  = menu_item_name.replace('?', '[question]')

    return menu_item_name
    
    
def decode_menu_item_name(menu_item_name):
    menu_item_name  = menu_item_name.replace('%20', ' ')
    menu_item_name  = menu_item_name.replace("&amp;", "&")
    menu_item_name  = menu_item_name.replace("[and]", "and")
    menu_item_name  = menu_item_name.replace('[equals]', '=')
    menu_item_name  = menu_item_name.replace('[question]', '?')

    return menu_item_name
    

def tidy(cmd):
    cmd = cmd.replace('&quot;', '')
    cmd = cmd.replace('&amp;', '&')

#    if cmd.startswith('RunScript'):
#        cmd = cmd.replace('?content_type=', '&content_type=')
#        cmd = re.sub('/&content_type=(.+?)"\)', '")', cmd)

    if cmd.endswith('/")'):
        cmd = cmd.replace('/")', '")')

    if cmd.endswith(')")'):
        cmd = cmd.replace(')")', ')')

    return cmd


def reverse_parse(cmd):
    cmd = cmd.replace('%20', ' ')
    cmd = cmd.replace('%22', '"')
    cmd = cmd.replace('%2c', ',')
    cmd = cmd.replace('%2C', ',')
    cmd = cmd.replace('%2f', '/')
    cmd = cmd.replace('%2F', '/')
    cmd = cmd.replace('%3a', ':')
    cmd = cmd.replace('%3A', ':')
    cmd = cmd.replace('%3d', '=')
    cmd = cmd.replace('%3D', '=')
    cmd = cmd.replace('%3f', '?')
    cmd = cmd.replace('%3F', '?')

    return cmd

    
def run_addon (cmd):
    cmd = reverse_parse(cmd)
    cmd = tidy(cmd)
    call_from_home = False
    try:    
        if cmd.startswith('HOME:'):
            cmd    = cmd.split(':', 1)[-1]
            call_from_home = True
    except: 
        pass

    # *** Execute the command
#    xbmc.executebuiltin('Dialog.Close(busydialog)')
    if (call_from_home): 
        script = os.path.join(HOME, 'homelauncher.py')
        cmd    = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % ('Run_from_Home', script, cmd.replace('"', ''), 0)
        xbmc.executebuiltin(cmd)
    else:
        xbmc.executebuiltin(cmd)


def run_window(cmd):
    xbmc.executebuiltin('Dialog.Close(busydialog)') #Isengard fix
    cmd = reverse_parse(cmd)

    # Get command from [HOME:]ActivateWindow(10025,"plugin://plugin.video.tvlisting")
    try:    
        if cmd.startswith('HOME:'):
            cmd = cmd.split(':', 1)[-1] # Drop the HOME:
            xbmc.executebuiltin('ActivateWindow(Home)') #some items don't play nicely if launched from wrong window
            xbmc.executebuiltin("ActivateWindow(10025,return)")
    except: 
        pass

    # Just in case return is missing
    if cmd.lower().startswith('activatewindow'):
        cmd = cmd.replace('&quot;', '"') # Use " instead of &quot;
        cmd = cmd.replace('",return)")', '",return)') # Malformed - Maybe in convert_favourite_2_menu     
        cmd = cmd.replace('")', '",return)')     

    # Check for url
    split = cmd.split('url=')
    if len(split) > 1: cmd = split[0] + "url=" + encode_url(split[1])

    time.sleep(1) # let window get caught update
    xbmc.sleep(250)
    xbmc.executebuiltin(cmd)
    time.sleep(2) # let window get caught update


def run_ectv_script(user_ID, cmd, execute, menu_name):
    if cmd or execute:
        # Check for ECTV updates
        ectv_check = 'RunScript(special://home/addons/script.ectv/default.py)'
        xbmc.executebuiltin(ectv_check)
        # Log action
        current_date_time   = datetime.now()
        log_program     = execute
        log_parameters  = cmd
        if (log_program == "window"):
            # eg: ActivateWindow(10025,"plugin://plugin.video.adina/?action=movie&iconImage=C:%5cUsers%5cmicro%5cAppData%5cRoaming%5cKodi%5caddons%5cscript.adinaart%5cresources%5cmedia%5csearch_movie.png&list_name=Search%20Movies&mode=search_history",return)
            plugin_start = log_parameters.find("plugin.")
            log_parameters = log_parameters[plugin_start:999]
            parameters_start = log_parameters.find("?")
            parameters_end = log_parameters.find("&")
            if (parameters_start == 0): parameters_end = 99
            log_program = log_parameters[0:parameters_start-1]
            log_parameters  = log_parameters[parameters_start:parameters_end]            
        if len(log_parameters) > 0: log_parameters = " (" + log_parameters + ")"
        data = {
            "user_ID": user_ID,
            "date_time": current_date_time,
            "addon": "Running Addon from Menu: " + log_program + log_parameters
        }
        encoded_data    = urllib.parse.urlencode(data)
        user_log_url    = WEB_PHP_PATH + USER_LOG_ROUTINE + "?" + encoded_data 
        try:
            urlopen(user_log_url)
        except:
            # Action not logged
            user_log_url = ""


def do_recent_channels ():

    global  recent_channels_file_name

    channel_array   = [] # Initialize channel names
    program_array   = [] # Initialize program names
    selection_array = [] # Initialize selection (channel + program)
    link_array      = [] # Initialize links

    # Make sure file exists
    if not os.path.isfile(recent_channels_file_name): 
        pass 
    else:
        # Parse Local File
        try:
            tree = ET.parse(recent_channels_file_name)
        except ET.ParseError as error_message:
            log("Recent Channels", error_message, xbmc.LOGERROR)
            pass
        else:
            # Get the menu items
            root = tree.getroot() 
            for branch in root.iter('channel'):
                channel_name    = branch.get('name')
                channel_name    = channel_name.replace("&amp;", "&")
                program_name    = ""
                if branch.get('program'): program_name = branch.get('program')
                program_name    = program_name.replace("&amp;", "&")
                link            = branch.text
                if program_name != "":
                    selection_array.append("[COLOR white][B]"+channel_name+"[/B][/COLOR] [COLOR grey]("+program_name+")[/COLOR]")
                else:
                    selection_array.append("[COLOR white][B]"+channel_name+"[/B][/COLOR]")
                channel_array.append(channel_name)
                program_array.append(program_name)
                link_array.append(link)

    # Router
    selection_number = xbmcgui.Dialog().select('Eagles Cliff TV', selection_array)
    if selection_number != -1: 
        channel = channel_array[selection_number]
        program = program_array[selection_number]
        link    = link_array[selection_number]
        notify("Tuning to channel: [COLOR white][B]"+channel+"[/B][/COLOR]...")
        execute_cmd = link
        execute_cmd = execute_cmd.replace("[and]", "&")
        execute_cmd = execute_cmd.replace("[equals]", "=")
        execute_cmd = 'PlayMedia("'+execute_cmd+'")'
        xbmc.executebuiltin(execute_cmd)
        save_recent_station (channel, program, link)


def save_recent_station (channel_name, program_name, playmedia):

    global  recent_channels_file_name

    output_data     = ''
    channel_name    = channel_name.replace("[B]", "")
    channel_name    = channel_name.replace("[/B]", "")
    channel_name    = channel_name.replace("[I]", "")
    channel_name    = channel_name.replace("[/I]", "")
    channel_name    = channel_name.replace("%20", " ")
    channel_name    = channel_name.replace("&amp;", "&")
    channel_name    = channel_name.replace("&", "&amp;")
    program_name    = program_name.replace("&amp;", "&")
    program_name    = program_name.replace("&", "&amp;")
    playmedia       = playmedia.replace("&", "[and]")
    playmedia       = playmedia.replace("=", "[equals]")

    # Make sure file exists
    if not os.path.isfile(recent_channels_file_name): 
        # Write first record
        output_data = '\n\t<channel name="'+channel_name+'" program="'+program_name+'">'+playmedia+'</channel>'
    else:
        # Parse Local File
        try:
            tree = ET.parse(recent_channels_file_name)
        except ET.ParseError as error_message:
            log("Recent Channels", error_message, xbmc.LOGERROR)
            pass
        else:
            # Get the menu items
            count = 0
            output_data = '\n\t<channel name="'+channel_name+'" program="'+program_name+'">'+playmedia+'</channel>'
            root = tree.getroot() 
            for branch in root.iter('channel'):
                file_channel    = branch.get('name')
                file_channel    = file_channel.replace("&amp;", "&")
                file_channel    = file_channel.replace("&", "&amp;")
                file_program    = ""
                if branch.get('program'): file_program = branch.get('program')
                file_program    = file_program.replace("&amp;", "&")
                file_program    = file_program.replace("&", "&amp;")
                file_link       = branch.text 
                if count < 49:
                    if file_channel != channel_name:
                        count = count + 1
                        output_data = output_data + '\n\t<channel name="'+file_channel+'" program="'+file_program+'">'+file_link+'</channel>'
    if output_data:
        output_data = '<channels>' + output_data + '\n</channels>'
        # Create the new file
        recent_channels = open(recent_channels_file_name,'w')
        recent_channels.write(output_data)
        recent_channels.close()
        
    
def notify(message, times=3000, sound=False):
    xbmcgui.Dialog().notification("ECTV Menu", message, 'special://home/addons/plugin.video.thelist/icon.png', int(times), sound)        
    

#=============================================================================
#==== Run the program
#=============================================================================

# ** Passed Variables
params                  = get_params(VARS)
try:    execute         = params['execute']
except: execute         = ""
try:    cmd             = params['cmd']
except: cmd             = ""
try:    url             = params['url']
except: url             = None
try:    reload          = params['reload']
except: reload          = None
try:    mode            = params['mode']
except: mode            = None
try:    path            = params['path']
except: path            = None
try:    menu_item_name  = params['menu_item_name']
except: menu_item_name  = ""

#xbmcgui.Dialog().ok("DEBUG", "VARS: "+str(VARS))    
#xbmcgui.Dialog().ok("DEBUG", "execute: "+str(execute))    
#xbmcgui.Dialog().ok("DEBUG", "cmd: "+str(cmd))    
if (execute == "window"): cmd = decode_url(cmd)

# *** Variables
recent_channels_file_name   = LOCAL_ECTV_PATH + "recent_channels.xml"

# Get the user ID
user_ID = get_user_ID()

# ** Check for ECTV Script Updates and log programs
if (execute != "recent_channels"): run_ectv_script(user_ID, cmd, execute, reload)


# ** Lists
name_list       = []
id_list         = []
thumb_list      = []
fanart_list     = []
desc_list       = []
execute_list    = []
hide_list       = []
link_date_list  = []
link_list       = []


# ** Special Case for ZOOM CATEGORY tvlisting, e.g. cmd = Sports%20Networks
if (execute == "tvlisting"):
    prefix = ""
    if cmd.startswith('HOME:'):
        prefix  = "HOME:"
        cmd     = cmd.split(':', 1)[-1]
    if cmd is not None:
        # Only write if not blank/None
        output_file = open(ECTV_PATH + "zoom_category.txt",'w')
        output_file.write(cmd.replace("%20", " "))
        output_file.close()
    cmd = prefix + 'RunAddon("plugin.video.tvlisting")'
    execute = "addon"


# Build based on execute type
if (execute == ""):
    if (reload == None): reload = "Menu" 
    # *** Build the listing
    reload = reload.replace("%20"," ") # ** Unparse file name
    reload = reload.replace(" ","_") # ** Safe name
    create_item_list(reload) # ** Build the item_list for the reload menu
    if (user_ID == "John" and reload != "Secret"): 
        name_list.append("Secret")
        id_list.append("Secret")
        thumb_list.append("https://1812cottages.com/kodi/media/menus/hidden.jpg")
        fanart_list.append("https://1812cottages.com/kodi/media/menus/hidden.jpg")
        desc_list.append("Secret")
        execute_list.append("folder")
        hide_list.append("")
        link_date_list.append("")
        link_list.append("Secret")
    send_files_to_xbmc(name_list, id_list, thumb_list, fanart_list, desc_list, execute_list, hide_list, link_date_list, link_list) # ** Send to XBMC


elif (execute == "playmedia"):
    # *** Check for call_from_home
    call_from_home = False
    try:    
        if cmd.startswith('HOME:'):
            cmd    = cmd.split(':', 1)[-1]
            call_from_home = True
    except: 
        pass

    # *** Execute the command
#    xbmc.executebuiltin('Dialog.Close(busydialog)')
    original_cmd = cmd
    cmd = cmd.replace("[and]", "&")
    cmd = cmd.replace("[equals]", "=")
    cmd = 'PlayMedia("'+cmd+'")'
    if (call_from_home): 
        script = os.path.join(HOME, 'homelauncher.py')
        cmd    = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % ('Run_from_Home', script, cmd.replace('"', ''), 0)
#    xbmcgui.Dialog().ok("DEBUG", "cmd:"+cmd)
    xbmc.executebuiltin(cmd)

    # Save Recent Play
    fenlight = cmd.find("fenlight")
    if (fenlight > 0): # Skip Movies or Series
        pass
    else:
        menu_item_name = decode_menu_item_name(menu_item_name)
        if menu_item_name != "": save_recent_station (menu_item_name, "", original_cmd)


elif (execute == "addon" or execute == "script"):
    run_addon(cmd)


elif (execute == "window"):
    #activate_window(cmd)
    run_window (cmd)

    
elif (execute == "recent_channels"):
    # Special Case for Recent Channels
    do_recent_channels ()

    
else:
    xbmcgui.Dialog().ok(ADDON_NAME, "Failed to execute type: "+str(execute))    
    
